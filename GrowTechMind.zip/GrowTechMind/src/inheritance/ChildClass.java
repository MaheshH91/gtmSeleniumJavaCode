package inheritance;

public class ChildClass extends ParentClass{
	static void add() {
		System.out.println("Add");
	}
public static void main(String[] args) {
	add();
	substract();
}
}

