package inheritance;

public class ParentClass {
	static void substract() {
		System.out.println("sub");
	}
}
