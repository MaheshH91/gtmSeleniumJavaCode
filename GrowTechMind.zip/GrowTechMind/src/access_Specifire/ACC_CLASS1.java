package access_Specifire;

public class ACC_CLASS1 {
	public void add() {
		System.out.println("1");
	}

	private void Sub() {
		System.out.println("2");
	}

	void div() {
		System.out.println("4");
	}

	protected void mul() {
		System.out.println("3");
	}
}
