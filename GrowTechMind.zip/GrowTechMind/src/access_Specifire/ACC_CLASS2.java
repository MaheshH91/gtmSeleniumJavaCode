package access_Specifire;

public class ACC_CLASS2 {
public static void main(String[] args) {
	ACC_CLASS1 reff =new ACC_CLASS1();
	reff.div();
	reff.mul();
	reff.add();
//	reff.sub();
}
}
