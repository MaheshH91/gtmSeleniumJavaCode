package package2;

import package1.ArtihmeticMethodsClass;

public class OperationClass {
public static void main(String[] args) {

	ArtihmeticMethodsClass a1 = new ArtihmeticMethodsClass();
	a1.add();
	
}
}
