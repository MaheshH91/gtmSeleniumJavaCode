package assignment1;

/*
Using return key-word return your name*/
class Assignment60 {

	public static String myName() {
		String name = "Mahesh Holkar";
		return name;

	}

	public static void main(String[] args) {
		System.out.println(myName());
	}
}
