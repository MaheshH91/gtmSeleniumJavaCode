package assignment1;

//11. WAP to find out the area of a SQure
public class Assignment11 {

	public static void main(String[] args) {
		int side = 20;
		int areaOfSquare= side * side;
		System.out.println("Area Of Square = "+areaOfSquare);
	}

}
