package assignment1;

/*
Convert any byte data type to long*/
public class Assignment51 {
	public static void main(String[] args) {

		byte b = 127	;
		long l = b;
		System.out.println(l);
	}
}