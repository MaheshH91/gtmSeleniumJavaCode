package assignment1;

//11. WAP to find out the area of a rectangle
public class Assignment12 {

	public static void main(String[] args) {
		
		int length = 20;
		int width = 43;
		int areaOfRectangle= length * width;
		System.out.println("Area Of Rectangle is: "+areaOfRectangle);
	}

}
