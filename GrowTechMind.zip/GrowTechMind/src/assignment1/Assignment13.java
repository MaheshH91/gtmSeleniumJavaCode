package assignment1;

//13. WAP to find out the area of a Circle
public class Assignment13 {

	public static void main(String[] args) {
		int r = 20;
		double pi = 3.14;
		double areaOfCircle =pi*r*r;
		System.out.println("Area Of Circle = "+areaOfCircle);
	}

}
