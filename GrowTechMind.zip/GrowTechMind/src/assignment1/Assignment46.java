package assignment1;

/*
input-  Leela    
        Sai      
output -LSeaeila
*/
public class Assignment46 {
	public static void main(String[] args) {
		String s1 = "Leela";
		String s2 = "Sai";

		System.out.print(s1.charAt(0));
		System.out.print(s2.charAt(0));
		System.out.print(s1.charAt(1));
		System.out.print(s2.charAt(1));
		System.out.print(s1.charAt(2));
		System.out.print(s2.charAt(2));
		System.out.print(s1.charAt(3));
		System.out.print(s1.charAt(4));
	}
}