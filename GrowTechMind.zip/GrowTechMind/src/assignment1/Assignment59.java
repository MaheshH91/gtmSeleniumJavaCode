package assignment1;

/*
By checking different parameters make 
the table ready for different classes of collection
*/

