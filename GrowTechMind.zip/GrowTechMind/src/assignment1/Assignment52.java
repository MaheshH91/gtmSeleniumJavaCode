package assignment1;

/*
Store a bigger value in long data type and convert into byte*/
public class Assignment52 {
	public static void main(String[] args) {
		long l=7655675677677567675l;
		byte b = (byte) l	;
		System.out.println(b);
	}
}