package assignment1;

//23. Logical Operator assignment 1(Ram,Sita)
public class Assignment24 {
	public static void main(String[] args) {

		String name = "Ram";
		char gender = 'M';

		if ((name=="Ram") && (gender=='M')) {
			System.out.println("Student1");
		} else if ((name=="Sita") && (gender=='F')) {
			System.out.println("Student2");
		}
		
	}
}
