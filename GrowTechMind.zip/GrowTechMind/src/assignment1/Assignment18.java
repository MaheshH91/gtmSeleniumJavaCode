package assignment1;

//18. Guess the output, where i=0;for(i=2; i<0; i++), print "Name". Print 'i', outside the loop.

public class Assignment18 {

	public static void main(String[] args) {
		int i=0;
		
		for(i=2; i<0; i++) {
			System.out.println("name");
		}
		System.out.println(i);
		//print out put as --> 2
	}

}
