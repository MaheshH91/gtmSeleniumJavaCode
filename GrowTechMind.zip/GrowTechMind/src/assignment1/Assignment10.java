package assignment1;

//Write a program java in which variable holds your age, *if age>18 print "I am eligible to vote"
public class Assignment10 {

	public static void main(String[] args) {
		int age = 21;
		if(age>18) {
			System.out.println("I am eligible to vote");
		}
		else {
			System.out.println("Sorry I am not able to vote");
		}
	}

}
