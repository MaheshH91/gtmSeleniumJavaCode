package assignment1;

// Assignment3 : WAP for Data type Variables
public class Assignment3 {
	public static void main(String[] args) {
		byte a = 100;
		short b = 9876;
		int c = 98765;
		long d = 9876543;
		float e = 9.545f;
		double f = 9.45d;
		char g = 'R';
		boolean h = true;
		boolean i = false;
		System.out.println("Byte: " + a);
		System.out.println("Short: " + b);
		System.out.println("int: " + c);
		System.out.println("long: " + d);
		System.out.println("float: " + e);
		System.out.println("double: " + f);
		System.out.println("char: " + g);
		System.out.println("boolean: " + h);
		System.out.println("boolean: " + i);

	}

}
