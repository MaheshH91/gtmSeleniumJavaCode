package stringAssignment;


class Assignment47 {

	public static void main(String[] args) {
		String str = "My Name Is Ram" ;
		
		for(int i=0; i<=str.length()-1;i++) {
			System.out.println(str.charAt(i));
		}
		
	}
}