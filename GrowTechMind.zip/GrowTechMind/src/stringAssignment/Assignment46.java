package stringAssignment;


class Assignment46 {

	public static void main(String[] args) {
		String str = "My Name Is Ram" ;
		String word[]= str.split(" ");
		for(int i=0; i<=word.length-1;i++) {
			System.out.println(word[i]);
		}
		
	}
}