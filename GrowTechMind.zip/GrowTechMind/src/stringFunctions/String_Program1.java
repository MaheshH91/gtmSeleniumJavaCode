package stringFunctions;

public class String_Program1 {
public static void main(String[] args) {
	String str = "Ayesha";
	String a = "FilpKart";
	boolean result = a.equals("Filpcarrt");
System.out.println(result);
boolean result1 = str.contains("F");

System.out.println(result1);
int strIndex = str.indexOf('y');
System.out.println(strIndex);




}
}
