
public class assignmentExamples {

}
