
package batch35;

public class Animal {
	void eat() {
		System.out.println("eat");
	}
}


