package batch35;

public class SwitchCase_Statement2 {

	public static void main(String[] args) {
		String browser = "Chrome";
		switch (browser) {
		case "Chrome":
			System.out.println("Chrome Browser launch");
			break;
		case "Firefox":
			System.out.println("Firefox Browser launch");
			break;
		case "Edge":
			System.out.println("Edge Browser launch");
			break;
		case "Opera":
			System.out.println("Opera Browser launch");
			break;
		default:
			System.out.println("Invalid Option");
			break;
		}

	}

}
