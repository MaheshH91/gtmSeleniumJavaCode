package batch35;

public class IIB__withMainMethod {

	{
		System.out.println("I am in IIB");
	}

	public static void main(String[] args) {
		new IIB__withMainMethod();
		System.out.println("I am in main method");

	}

}
