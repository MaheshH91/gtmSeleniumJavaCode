package batch35;

public class DataTypeVariable {
//c
	public static void main(String[] args) {
	byte a = 100;
	System.out.println(a);
	short b = 9876;
	System.out.println(b);
	int c= 98765;
	System.out.println(c);
	long d = 9876543;
	System.out.println(d);
	float e = 9.545f;
	System.out.println(e);
	double f = 9.45;
	System.out.println(f);
	char g= 'R';
	System.out.println(g);
	boolean h = true;
	System.out.println(h);
	boolean i= false;
	System.out.println(i);
	String j = "Mahesh Rajendra Holkar";
	System.out.println(j);
	
	
		
	}

}
