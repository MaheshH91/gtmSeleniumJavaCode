package batch35;

public class ForLoop {
	public static void main(String[] args) {
		for (int i = 3; i > 2; i--) {
			System.out.println("India");
		}

	}
}
