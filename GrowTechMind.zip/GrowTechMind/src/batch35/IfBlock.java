package batch35;

public class IfBlock {

	public static void main(String[] args) {
		int a = 10;
		int b = 5;
		if (a > b) {
			int c = a + b;
			System.out.println(c);
		}

	}

}
