package batch35;

public class Arithmatic {

	static void addition() {
		int no1 = 10;
		int no2 = 20;
		int result = no1 + no2;
		System.out.println(result);
	}

	static void substraction() {
		int no1 = 10;
		int no2 = 20;
		int result = no1 - no2;
		System.out.println(result);
	}

	static void multiplication() {
		int no1 = 10;
		int no2 = 20;
		int result = no1 * no2;
		System.out.println(result);
	}

	static void division() {
		int no1 = 10;
		int no2 = 20;
		int result = no2 / no1;
		System.out.println(result);
	}

	public static void main(String[] args) {
		System.out.println("Output will be start from here..");
		addition();
		substraction();
		multiplication();
		division();

	}
}
