package batch35;

public class LocalGlobalVariable {
	static int a;

	public static void main(String[] args) {
		try {
			System.out.println(a);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
