package batch35;

public class IfElse {

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		if (a > b) {
			System.out.println("Lets Start Addition");
		} else {
			System.out.println("Lets Start Substraction");
		}

	}

}
