package batch35;

public class GlobalAndLocalvariable {

}
