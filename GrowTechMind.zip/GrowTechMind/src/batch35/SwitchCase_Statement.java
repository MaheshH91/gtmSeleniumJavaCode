package batch35;

public class SwitchCase_Statement {

	public static void main(String[] args) {
		switch (2) {
		case 1:
			System.out.println("Chrome Browser launch");
			break;
		case 2:
			System.out.println("Firefox Browser launch");
			break;
		case 3:
			System.out.println("Edge Browser launch");
			break;
		case 4:
			System.out.println("Opera Browser launch");
			break;
		default:
			System.out.println("No browser is selected");
			break;
		}

	}

}
