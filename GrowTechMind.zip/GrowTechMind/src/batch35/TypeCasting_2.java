package batch35;

public class TypeCasting_2 {

	public static void main(String[] args) {
		long a = 342354353;
		short b = (short) a;
		System.out.println(b);

	}

}
