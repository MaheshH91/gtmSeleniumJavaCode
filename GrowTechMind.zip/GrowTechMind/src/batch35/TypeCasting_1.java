package batch35;
// Convert weight = 85 convert it into double
public class TypeCasting_1 {

    public static void main(String[] args) {
       

        double myweight = 90.5;

        // Casting from double to int (explicit casting)
        int myWeight1 = (int) myweight; // This is explicit casting (double to int)
        System.out.println(myWeight1);

        // Convert double into short
        double a = 987.875;

        // Casting from double to short (explicit casting)
        short b = (short) a; // This is explicit casting (double to short)
        System.out.println(b);
    }
}

