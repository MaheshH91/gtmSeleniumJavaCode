package batch35;

public class Addition {

	static void add() {
		System.out.println("Addtion");
	}
	static void sub() {
		System.out.println("Substraction");
	}
	public static void main(String[] args) {
		System.out.println("I am Starting");
		sub();
		add();
	}
	

}
