package batch35;

public class Return_Keyword {
static int add() {
	int a= 10;
	int b= 20;
	int c= a+b;
	return c;
}
	public static void main(String[] args) {
		System.out.println(add());

	}

}
