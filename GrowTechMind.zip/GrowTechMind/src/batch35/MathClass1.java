package batch35;

public class MathClass1 {
	public static void main(String[] args) {
		System.out.println(Math.PI);
		System.out.println(Math.abs(-999));
		System.out.println(Math.addExact(66, 34));
		System.out.println(Math.subtractExact(11, 3));
		System.out.println(Math.random()); // random number between 0.0 and 1.0 in
		// What is imporance of random function in automation testing
	}
}
