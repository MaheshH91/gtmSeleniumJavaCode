package batch35;

public class ThrowExceptio_Demo {


	public static void main(String[] args) {
		throw new ArithmeticException("your still young");

	}

}
