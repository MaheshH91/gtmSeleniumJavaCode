package batch35;
// Convert weight = 85 convert it into double
public class TypeCasting_4 {

	public static void main(String[] args) {
		int weight = 85;
		double weight1= (double) weight;
		System.out.println(weight1);

	}

}
