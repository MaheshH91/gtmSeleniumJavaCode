package batch35;

public class Encapsulation_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
