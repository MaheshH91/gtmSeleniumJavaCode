package batch35;

public class Manish2 {

	public static void main(String[] args) 
	{
		Manish2 m1=new Manish2();
		System.out.println(	m1.getClass());
	}

}
