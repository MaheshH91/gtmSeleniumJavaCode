package access_Specifire1;

import access_Specifire.AccessSpecifire;

public class OperationsClass extends AccessSpecifire{
public static void main(String[] args) {
	OperationsClass op = new OperationsClass();
	op.add();
	op.mul();
//	op.div();
//	op.sub
}
}
