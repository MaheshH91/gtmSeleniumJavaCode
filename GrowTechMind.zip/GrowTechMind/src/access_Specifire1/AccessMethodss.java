package access_Specifire1;

import access_Specifire.AccessMethods;

public class AccessMethodss {
public static void main(String[] args) {
	AccessMethods ref= new AccessMethods();
	ref.add();

}
}
