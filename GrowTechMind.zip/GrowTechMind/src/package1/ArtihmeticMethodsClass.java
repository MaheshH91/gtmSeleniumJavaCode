package package1;

public class ArtihmeticMethodsClass {
	public void add() {
		System.out.println("1");
	}

	private void subs() {
		System.out.println("2");
	}

	void div() {
		System.out.println("4");
	}

	protected void mul() {
		System.out.println("3");
	}
}
