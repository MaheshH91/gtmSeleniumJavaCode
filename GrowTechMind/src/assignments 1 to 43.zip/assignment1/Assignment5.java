package assignment1;

//Write a Java program for Arithmetic Operators
public class Assignment5 {

	public static void main(String[] args) {
		int a = 10;
		int b = 5;
		int sum = a + b;// Addition
		System.out.println("The Sum is: " + sum);
		int diff = a + b;// Substraction
		System.out.println("The difference is: " + diff);
		int mul = a * b;// Multiplication
		System.out.println("The multiplcation is: " + mul);
		int div = a / b;	// Div
		System.out.println("The Quotient is: " + div);
		int mod = a % b;// Modulus
		System.out.println("The reminder is: " + mod);
		int value = 7; 
		value++; //increment
		System.out.println("Increment value: " + value);
		value--;// decrement
		System.out.println("Decrement value: " + value);
	}

}
