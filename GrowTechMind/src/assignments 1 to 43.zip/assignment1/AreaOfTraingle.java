package assignment1;

public class AreaOfTraingle {

	public static void main(String[] args) {

	float b = 10, h =13, area;
	area = (b*h)/2;
	
		System.out.println("The area of Traingle is: "+area);
	}

}
