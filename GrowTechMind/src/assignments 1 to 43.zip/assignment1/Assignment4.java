package assignment1;

//write a java program create multiple static methods and call them inside the main method

public class Assignment4 {

	public static void add() {
		System.out.println("1");
	}
	static void sub() {
		System.out.println("2");
	}
	static void div() {
		System.out.println("4");
	}
	public static void mul() {
		System.out.println("3");
	}
	public static void main(String[] args) {
		add();
		sub();
		mul();
		div();
	}

}
