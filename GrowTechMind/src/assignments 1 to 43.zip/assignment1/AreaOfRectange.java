package assignment1;

public class AreaOfRectange {
	public static void main(String args[]) {
		int width = 5;
		int height = 10;
		int area = width * height;
		System.out.println("Area of rectangle=" + area);
	}
}
