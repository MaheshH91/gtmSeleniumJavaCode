package assignment1;

public class AreaofCircle {

	public static void main(String[] args) {
		int radious = 10;
		double pi = 3.14;
		double area = pi * radious * radious;
		System.out.println("Area of circle: " + area);

	}
}