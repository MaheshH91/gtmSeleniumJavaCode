package assignment1;

public class Assignment31_SubClass2 extends Assignment31_SuperClass {

	public static void main(String[] args) {
		staticMethod();
		Assignment31_SubClass2 ref = new Assignment31_SubClass2();
		ref.notStaticMethod(41);
	}
}
