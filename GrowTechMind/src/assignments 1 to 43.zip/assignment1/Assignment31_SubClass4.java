package assignment1;

public class Assignment31_SubClass4 extends Assignment31_SuperClass {

	public static void main(String[] args) {
		staticMethod();
		Assignment31_SubClass4 ref = new Assignment31_SubClass4();
		ref.notStaticMethod(61);
	}
}
