package assignment1;

//17. WAP to print +100 to -10

public class Assignment17 {

	public static void main(String[] args) {
		
		for(int i= +100; i>= -10;i--) {
			System.out.println(i);
		}
	}

}
