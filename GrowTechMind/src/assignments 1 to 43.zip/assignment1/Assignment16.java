package assignment1;

//16 WAP to print -500 to -800
public class Assignment16 {

	public static void main(String[] args) {
		
		for(int i= -500; i>= -800;i--) {
			System.out.println(i);
		}
	}

}
