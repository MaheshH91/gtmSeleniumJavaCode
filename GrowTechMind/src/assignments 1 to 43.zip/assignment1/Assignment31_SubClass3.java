package assignment1;

public class Assignment31_SubClass3 extends Assignment31_SuperClass {

	public static void main(String[] args) {
		staticMethod();
		Assignment31_SuperClass ref = new Assignment31_SuperClass();
		ref.notStaticMethod(51);
	}
}
