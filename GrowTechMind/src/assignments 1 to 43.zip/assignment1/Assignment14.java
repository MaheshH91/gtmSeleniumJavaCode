package assignment1;

//14. WAP to find out the area of a Triangle
public class Assignment14 {

	public static void main(String[] args) {
		int base = 10;
		int height = 15;
		
		
		
		double areaOfTraingle = 0.5 * base * height;
		System.out.println("Area Of Traingle = " + areaOfTraingle);
	}

}
