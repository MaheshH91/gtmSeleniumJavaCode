package assignment1;
//Assignment 2:  WAP to use comparison operators

public class Assignment2 {
public static void main(String[] args) {
	int a = 10;
	int b= 20;
	if(a==b) {
		System.out.println("a is equals to b");
	}
	else if(a> b) {
		System.out.println("a is greater than b");
	}
	else {
		System.out.println("a is less than b");
	}
			
}
}
