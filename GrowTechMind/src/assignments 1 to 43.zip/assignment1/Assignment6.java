package assignment1;

//if condition, if else codition
public class Assignment6 {

	public static void main(String[] args) {
		int num1 = 10;
		//if
		if (num1>0) {
			System.out.println("number is positive");
		}
		//if else
		if(num1%2==0) {
			System.out.println("number is even");
		}
		else {
			System.out.println("number is odd");
		}
		
	}

}
