package assignment1;
// Assignment 1 : Print your name
public class Assignment1 {

	public static void main(String[] args) {

		System.out.println("Mahesh");
	}

}
