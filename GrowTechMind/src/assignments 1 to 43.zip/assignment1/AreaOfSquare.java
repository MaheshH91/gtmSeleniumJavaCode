package assignment1;

public class AreaOfSquare {

	public static void main(String[] args) {
		int s = 13;
		int area_square = s * s;
		System.out.println("Area of the square=" + area_square);
	}

}
