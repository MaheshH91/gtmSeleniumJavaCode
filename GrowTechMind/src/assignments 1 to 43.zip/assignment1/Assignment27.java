package assignment1;

//Assignment27 create a final variable & try to update it
public class Assignment27 {
	
    public static void main(String[] args) {
    	final int a = 10;
    	System.out.println(a=a+12);
    }
}

